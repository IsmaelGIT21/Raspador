public abstract class Carregador <T> {
 public abstract void carregar (List <T> item);   
}
