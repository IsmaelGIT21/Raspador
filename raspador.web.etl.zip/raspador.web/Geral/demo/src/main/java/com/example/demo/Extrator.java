public abstract class Extrator <T> {
    public abstract List <T> extrair();
}
