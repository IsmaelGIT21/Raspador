import java.util.List;

public class Job <T> {
    
    private Extrator <T> extrator;
    private Transformar <T, O> transformador;
    private Carregador <T> carregador;
    public void setExtrator(Extrator<T> extrator) {
        this.extrator = extrator;
    }
    public void setTransformador(Transformar<T, O> transformador) {
        this.transformador = transformador;
    }
    public void setCarregador(Carregador<T> carregador) {
        this.carregador = carregador;
    }
    public void executar(){
        List <T> lista = extrator.extrair();
        for (T item : lista){
            transformador.transformador(item);
        }
        carregador.carregar(lista);
    }
}
